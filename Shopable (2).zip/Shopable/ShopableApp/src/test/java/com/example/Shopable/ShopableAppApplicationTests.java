package com.example.Shopable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopableAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
